module.exports = {
  reactStrictMode: false,
  images: {
    loader: "imgix",
    path: "https://noop/",
},
};
